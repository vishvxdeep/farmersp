import React from 'react';

const Title = () => {

  return (
      <>
        Lost& Found Items Finder App
      </>
  );
};


export default Title;
